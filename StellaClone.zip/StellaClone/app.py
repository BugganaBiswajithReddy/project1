from flask import Flask, render_template, request, jsonify, session
from flask_cors import CORS
import os
import json
from datetime import datetime
import google.generativeai as genai
from duckduckgo_search import DDGS
from apscheduler.schedulers.background import BackgroundScheduler
import subprocess
import platform

try:
    from email_service import send_email, parse_email_command
    EMAIL_AVAILABLE = True
except:
    EMAIL_AVAILABLE = False

try:
    from calendar_service import get_calendar_events
    CALENDAR_AVAILABLE = True
except:
    CALENDAR_AVAILABLE = False

try:
    from reminder_service import add_reminder, parse_reminder_command
    REMINDER_AVAILABLE = True
except:
    REMINDER_AVAILABLE = False

app = Flask(__name__)
app.secret_key = os.environ.get('SESSION_SECRET', 'dev-secret-key-change-in-production')
app.config['SESSION_COOKIE_SAMESITE'] = 'None'
app.config['SESSION_COOKIE_SECURE'] = False
CORS(app, supports_credentials=True)

GOOGLE_API_KEY = os.environ.get('GOOGLE_API_KEY', '')
if GOOGLE_API_KEY:
    genai.configure(api_key=GOOGLE_API_KEY)
    model = genai.GenerativeModel('gemini-1.5-flash')
else:
    model = None

scheduler = BackgroundScheduler()
scheduler.start()

TASKS_FILE = 'tasks.json'
REMINDERS_FILE = 'reminders.json'

def load_json_file(filename):
    if os.path.exists(filename):
        with open(filename, 'r') as f:
            return json.load(f)
    return []

def save_json_file(filename, data):
    with open(filename, 'w') as f:
        json.dump(data, f, indent=2)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.json
    user_message = data.get('message', '')
    
    if not user_message:
        return jsonify({'error': 'No message provided'}), 400
    
    if not model:
        return jsonify({'error': 'Google Gemini API key not configured. Please add GOOGLE_API_KEY to your secrets.'}), 500
    
    try:
        conversation_history = session.get('conversation_history', [])
        conversation_history.append({'role': 'user', 'content': user_message})
        
        system_prompt = """You are Stella, an intelligent voice assistant. You can help users with:
1. Answering questions and having conversations
2. Web searches (use search_web function)
3. Managing tasks (use task functions)
4. Setting reminders (use reminder functions)
5. File management (use file functions)
6. Email and calendar operations (when credentials are configured)

Respond naturally and helpfully. When users ask you to perform actions, use the appropriate functions."""
        
        full_context = system_prompt + "\n\n" + "\n".join([f"{msg['role']}: {msg['content']}" for msg in conversation_history[-5:]])
        
        intent = detect_intent(user_message.lower())
        
        if intent == 'search':
            response = handle_search(user_message)
        elif intent == 'task':
            response = handle_task_command(user_message)
        elif intent == 'reminder':
            response = handle_reminder_command(user_message)
        elif intent == 'file':
            response = handle_file_command(user_message)
        elif intent == 'email':
            response = handle_email_command(user_message)
        elif intent == 'calendar':
            response = handle_calendar_command(user_message)
        else:
            response_obj = model.generate_content(full_context)
            response = response_obj.text
        
        conversation_history.append({'role': 'assistant', 'content': response})
        session['conversation_history'] = conversation_history[-10:]
        
        return jsonify({'response': response, 'intent': intent})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def detect_intent(message):
    search_keywords = ['search', 'look up', 'find information', 'google', 'what is', 'who is', 'where is']
    task_keywords = ['task', 'todo', 'add to my list', 'create task']
    reminder_keywords = ['remind me', 'set reminder', 'reminder for']
    file_keywords = ['open file', 'create file', 'delete file', 'find file', 'search file', 'list files', 'show files']
    email_keywords = ['send email', 'email to', 'send mail']
    calendar_keywords = ['calendar', 'events', 'schedule', 'what\'s on my calendar']
    
    if any(keyword in message for keyword in search_keywords):
        return 'search'
    elif any(keyword in message for keyword in task_keywords):
        return 'task'
    elif any(keyword in message for keyword in reminder_keywords):
        return 'reminder'
    elif any(keyword in message for keyword in file_keywords):
        return 'file'
    elif any(keyword in message for keyword in email_keywords):
        return 'email'
    elif any(keyword in message for keyword in calendar_keywords):
        return 'calendar'
    
    return 'chat'

def handle_search(query):
    try:
        search_query = query.replace('search', '').replace('look up', '').replace('find information about', '').strip()
        
        with DDGS() as ddgs:
            results = list(ddgs.text(search_query, max_results=3))
        
        if results:
            summary = f"Here's what I found about '{search_query}':\n\n"
            for i, result in enumerate(results, 1):
                summary += f"{i}. {result['title']}\n{result['body'][:150]}...\n\n"
            return summary
        else:
            return f"I couldn't find any information about '{search_query}'."
    
    except Exception as e:
        return f"Sorry, I encountered an error while searching: {str(e)}"

def handle_task_command(message):
    tasks = load_json_file(TASKS_FILE)
    
    if 'create task' in message or 'add task' in message:
        task_text = message.replace('create task', '').replace('add task', '').strip()
        new_task = {
            'id': len(tasks) + 1,
            'text': task_text,
            'created': datetime.now().isoformat(),
            'completed': False
        }
        tasks.append(new_task)
        save_json_file(TASKS_FILE, tasks)
        return f"Task created: {task_text}"
    
    elif 'list tasks' in message or 'show tasks' in message:
        if not tasks:
            return "You have no tasks."
        task_list = "Your tasks:\n"
        for task in tasks:
            status = "✓" if task['completed'] else "○"
            task_list += f"{status} {task['text']}\n"
        return task_list
    
    elif 'complete task' in message:
        try:
            task_id = int(''.join(filter(str.isdigit, message)))
            for task in tasks:
                if task['id'] == task_id:
                    task['completed'] = True
                    save_json_file(TASKS_FILE, tasks)
                    return f"Task completed: {task['text']}"
            return "Task not found."
        except:
            return "Please specify a task number."
    
    return "I can help you create, list, or complete tasks. What would you like to do?"

def handle_reminder_command(message):
    if not REMINDER_AVAILABLE:
        return "Reminder service is not available at the moment."
    
    try:
        reminder_message, minutes = parse_reminder_command(message)
        if reminder_message and minutes is not None:
            return add_reminder(reminder_message, minutes)
        else:
            return "Please specify what you'd like to be reminded about and when. Example: 'Remind me to call John in 30 minutes'"
    except Exception as e:
        return f"Error setting reminder: {str(e)}"

def handle_email_command(message):
    if not EMAIL_AVAILABLE:
        return "Email service is not configured. Please add credentials.json file to enable email functionality."
    
    try:
        recipient, subject, body = parse_email_command(message)
        if recipient and body:
            return send_email(recipient, subject, body)
        else:
            return "Please specify recipient, subject, and body. Example: 'Send email to john@example.com subject Meeting reminder body Don't forget our meeting tomorrow'"
    except Exception as e:
        return f"Error sending email: {str(e)}"

def handle_calendar_command(message):
    if not CALENDAR_AVAILABLE:
        return "Calendar service is not configured. Please add credentials.json file to enable calendar functionality."
    
    try:
        return get_calendar_events()
    except Exception as e:
        return f"Error fetching calendar events: {str(e)}"

def handle_file_command(message):
    try:
        if 'open file' in message:
            filename = message.replace('open file', '').strip()
            if os.path.exists(filename):
                try:
                    if platform.system() == 'Darwin':
                        subprocess.run(['open', filename])
                    elif platform.system() == 'Windows':
                        subprocess.run(['cmd', '/c', 'start', '', filename], shell=True)
                    else:
                        subprocess.run(['xdg-open', filename])
                    return f"Opened file: {filename}"
                except Exception as e:
                    return f"File opening is not supported in this environment. File location: {os.path.abspath(filename)}"
            else:
                return f"File not found: {filename}"
        
        elif 'list files' in message or 'show files' in message:
            files = os.listdir('.')
            return "Files in current directory:\n" + "\n".join(files[:20])
        
        elif 'create file' in message:
            filename = message.replace('create file', '').strip()
            with open(filename, 'w') as f:
                f.write('')
            return f"Created file: {filename}"
        
        return "I can help you open, list, or create files. What would you like to do?"
    
    except Exception as e:
        return f"Error with file operation: {str(e)}"

@app.route('/api/tasks', methods=['GET', 'POST', 'PUT', 'DELETE'])
def manage_tasks():
    tasks = load_json_file(TASKS_FILE)
    
    if request.method == 'GET':
        return jsonify(tasks)
    
    elif request.method == 'POST':
        data = request.json
        new_task = {
            'id': len(tasks) + 1,
            'text': data.get('text'),
            'created': datetime.now().isoformat(),
            'completed': False
        }
        tasks.append(new_task)
        save_json_file(TASKS_FILE, tasks)
        return jsonify(new_task)
    
    elif request.method == 'PUT':
        data = request.json
        task_id = data.get('id')
        for task in tasks:
            if task['id'] == task_id:
                task['completed'] = data.get('completed', task['completed'])
                task['text'] = data.get('text', task['text'])
                save_json_file(TASKS_FILE, tasks)
                return jsonify(task)
        return jsonify({'error': 'Task not found'}), 404
    
    elif request.method == 'DELETE':
        task_id = request.args.get('id', type=int)
        tasks = [task for task in tasks if task['id'] != task_id]
        save_json_file(TASKS_FILE, tasks)
        return jsonify({'success': True})

@app.route('/api/status', methods=['GET'])
def status():
    return jsonify({
        'gemini_configured': bool(GOOGLE_API_KEY),
        'features': {
            'ai_chat': bool(GOOGLE_API_KEY),
            'web_search': True,
            'tasks': True,
            'reminders': REMINDER_AVAILABLE,
            'files': True,
            'email': EMAIL_AVAILABLE,
            'calendar': CALENDAR_AVAILABLE
        }
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
