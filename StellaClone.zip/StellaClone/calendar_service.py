import os
import pickle
from datetime import datetime, timedelta
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/calendar.readonly']
TOKEN_FILE = 'token_calendar.pickle'
CREDENTIALS_FILE = 'credentials.json'

def get_calendar_service():
    creds = None
    
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, 'rb') as token:
            creds = pickle.load(token)
    
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not os.path.exists(CREDENTIALS_FILE):
                raise FileNotFoundError('credentials.json file not found. Please add your Google Cloud OAuth credentials.')
            
            flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_FILE, SCOPES)
            creds = flow.run_local_server(port=0)
        
        with open(TOKEN_FILE, 'wb') as token:
            pickle.dump(creds, token)
    
    return build('calendar', 'v3', credentials=creds)

def get_calendar_events(max_results=10):
    try:
        service = get_calendar_service()
        
        now = datetime.utcnow().isoformat() + 'Z'
        
        events_result = service.events().list(
            calendarId='primary',
            timeMin=now,
            maxResults=max_results,
            singleEvents=True,
            orderBy='startTime'
        ).execute()
        
        events = events_result.get('items', [])
        
        if not events:
            return 'No upcoming events found.'
        
        response = 'Your upcoming events:\n\n'
        for event in events:
            start = event['start'].get('dateTime', event['start'].get('date'))
            summary = event.get('summary', 'No title')
            
            try:
                start_dt = datetime.fromisoformat(start.replace('Z', '+00:00'))
                formatted_time = start_dt.strftime('%B %d, %Y at %I:%M %p')
            except:
                formatted_time = start
            
            response += f"• {summary}\n  {formatted_time}\n\n"
        
        return response
    
    except FileNotFoundError as e:
        return str(e)
    except Exception as e:
        return f"Error fetching calendar events: {str(e)}"
