import os
import pickle
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from email.mime.text import MIMEText
import base64

SCOPES = ['https://www.googleapis.com/auth/gmail.send']
TOKEN_FILE = 'token_gmail.pickle'
CREDENTIALS_FILE = 'credentials.json'

def get_gmail_service():
    creds = None
    
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, 'rb') as token:
            creds = pickle.load(token)
    
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not os.path.exists(CREDENTIALS_FILE):
                raise FileNotFoundError('credentials.json file not found. Please add your Google Cloud OAuth credentials.')
            
            flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_FILE, SCOPES)
            creds = flow.run_local_server(port=0)
        
        with open(TOKEN_FILE, 'wb') as token:
            pickle.dump(creds, token)
    
    return build('gmail', 'v1', credentials=creds)

def send_email(to_email, subject, body):
    try:
        service = get_gmail_service()
        
        message = MIMEText(body)
        message['to'] = to_email
        message['subject'] = subject
        
        raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode('utf-8')
        
        send_message = service.users().messages().send(
            userId='me',
            body={'raw': raw_message}
        ).execute()
        
        return f"Email sent successfully to {to_email}"
    
    except FileNotFoundError as e:
        return str(e)
    except Exception as e:
        return f"Error sending email: {str(e)}"

def parse_email_command(command):
    try:
        parts = command.lower().split('to')
        if len(parts) < 2:
            return None, None, None
        
        subject_body = parts[0].replace('send email', '').strip()
        recipient = parts[1].strip()
        
        if 'subject' in subject_body:
            subject_parts = subject_body.split('subject')
            body = subject_parts[0].strip()
            subject = subject_parts[1].strip() if len(subject_parts) > 1 else 'No Subject'
        else:
            body = subject_body
            subject = 'No Subject'
        
        return recipient, subject, body
    
    except Exception as e:
        return None, None, None
