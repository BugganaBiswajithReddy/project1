import json
import os
from datetime import datetime, timedelta
from apscheduler.schedulers.background import BackgroundScheduler

REMINDERS_FILE = 'reminders.json'

scheduler = BackgroundScheduler()
scheduler.start()

def load_reminders():
    if os.path.exists(REMINDERS_FILE):
        with open(REMINDERS_FILE, 'r') as f:
            return json.load(f)
    return []

def save_reminders(reminders):
    with open(REMINDERS_FILE, 'w') as f:
        json.dump(reminders, f, indent=2)

def reminder_callback(reminder_id, message):
    print(f"REMINDER: {message}")

def add_reminder(message, minutes_from_now=5):
    reminders = load_reminders()
    
    reminder_time = datetime.now() + timedelta(minutes=minutes_from_now)
    
    reminder = {
        'id': len(reminders) + 1,
        'message': message,
        'time': reminder_time.isoformat(),
        'triggered': False
    }
    
    reminders.append(reminder)
    save_reminders(reminders)
    
    scheduler.add_job(
        reminder_callback,
        'date',
        run_date=reminder_time,
        args=[reminder['id'], message],
        id=f"reminder_{reminder['id']}"
    )
    
    return f"Reminder set for {minutes_from_now} minutes from now: {message}"

def parse_reminder_command(command):
    try:
        if 'in' in command:
            parts = command.split('in')
            message = parts[0].replace('remind me', '').replace('to', '').strip()
            time_part = parts[1].strip()
            
            if 'minute' in time_part:
                minutes = int(''.join(filter(str.isdigit, time_part)))
                return message, minutes
            elif 'hour' in time_part:
                hours = int(''.join(filter(str.isdigit, time_part)))
                return message, hours * 60
        
        message = command.replace('remind me', '').replace('to', '').strip()
        return message, 5
    
    except Exception as e:
        return None, None
