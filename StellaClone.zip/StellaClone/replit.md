# Stella Voice Assistant

A comprehensive web-based voice assistant built with Flask and Python, featuring AI-powered responses, speech recognition, and multiple productivity features.

## Overview

Stella is an intelligent voice assistant similar to the original Stella project (https://github.com/TheM1N9/stella). This version is web-based and includes voice interaction, AI responses, task management, web search, and optional email/calendar integration.

## Project Architecture

### Backend (Python/Flask)
- **app.py**: Main Flask application with API endpoints
- **email_service.py**: Gmail integration with OAuth2
- **calendar_service.py**: Google Calendar integration
- **reminder_service.py**: Reminder system with APScheduler

### Frontend
- **templates/index.html**: Main UI
- **static/css/style.css**: Modern dark theme with animations
- **static/js/script.js**: Voice recognition and UI logic

## Features Implemented

✅ **Voice Interaction**: Web Speech API for speech-to-text and text-to-speech
✅ **AI Responses**: Google Gemini integration for natural conversations
✅ **Web Search**: DuckDuckGo search integration
✅ **Task Management**: Create, view, complete, and delete tasks
✅ **File Operations**: List, create, and open files
✅ **Reminder System**: Set timed reminders with notifications
✅ **Email Integration**: Send emails via Gmail API (requires credentials)
✅ **Calendar Integration**: View Google Calendar events (requires credentials)

## Current State

- Server running on port 5000
- All core features functional
- Beautiful dark-themed UI with gradient effects
- Voice recognition working in Chrome/Edge browsers
- Task management system operational
- Web search functional

## API Keys Required

### Essential (for AI responses)
- `GOOGLE_API_KEY`: Google Gemini API key for AI conversations

### Optional (for email/calendar features)
- `credentials.json`: Google Cloud OAuth credentials for Gmail and Calendar APIs

## Setup Instructions

1. **Add Google Gemini API Key**:
   - Get key from https://makersuite.google.com/app/apikey
   - Add to Replit Secrets as `GOOGLE_API_KEY`

2. **Optional - Add Gmail/Calendar**:
   - Create Google Cloud project
   - Enable Gmail API and Calendar API
   - Create OAuth Desktop credentials
   - Download credentials.json to project root
   - First use will prompt for authorization

## Recent Changes

- Fixed reminder parsing to handle invalid input gracefully
- Fixed file operations to work cross-platform
- Implemented modern UI with glassmorphism effects
- Added comprehensive error handling

## User Preferences

None documented yet.

## Notes

- Voice recognition requires Chrome or Edge browser
- Email and Calendar features are optional and require setup
- All task and reminder data stored locally in JSON files
- Session-based conversation history (resets on browser refresh)
