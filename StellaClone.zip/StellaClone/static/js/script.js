let isListening = false;
let recognition = null;
let synthesis = window.speechSynthesis;
let conversationHistory = [];

if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
        isListening = true;
        updateVoiceUI(true);
        updateVoiceStatus('Listening...');
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        document.getElementById('messageInput').value = transcript;
        sendMessage();
    };

    recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        updateVoiceUI(false);
        updateVoiceStatus('Error: ' + event.error);
    };

    recognition.onend = () => {
        isListening = false;
        updateVoiceUI(false);
        updateVoiceStatus('Click to speak');
    };
}

function toggleVoice() {
    if (!recognition) {
        alert('Speech recognition is not supported in this browser. Please use Chrome or Edge.');
        return;
    }

    if (isListening) {
        recognition.stop();
    } else {
        recognition.start();
    }
}

function updateVoiceUI(listening) {
    const micButton = document.getElementById('micButton');
    const waveform = document.getElementById('waveform');
    
    if (listening) {
        micButton.classList.add('listening');
        waveform.classList.add('active');
    } else {
        micButton.classList.remove('listening');
        waveform.classList.remove('active');
    }
}

function updateVoiceStatus(status) {
    document.getElementById('voiceStatus').textContent = status;
}

function updateStatus(text, type = 'ready') {
    const statusText = document.getElementById('statusText');
    const statusDot = document.querySelector('.status-dot');
    
    statusText.textContent = text;
    
    if (type === 'processing') {
        statusDot.style.background = '#f59e0b';
    } else if (type === 'error') {
        statusDot.style.background = '#ef4444';
    } else {
        statusDot.style.background = '#10b981';
    }
}

function addMessage(text, isUser = false) {
    const chatContainer = document.getElementById('chatContainer');
    const welcomeMessage = chatContainer.querySelector('.welcome-message');
    
    if (welcomeMessage) {
        welcomeMessage.remove();
    }

    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isUser ? 'user' : 'assistant'}`;
    
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = isUser ? '👤' : '✨';
    
    const content = document.createElement('div');
    content.className = 'message-content';
    
    const textDiv = document.createElement('div');
    textDiv.className = 'message-text';
    textDiv.textContent = text;
    
    content.appendChild(textDiv);
    messageDiv.appendChild(avatar);
    messageDiv.appendChild(content);
    
    chatContainer.appendChild(messageDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;
    
    conversationHistory.push({ role: isUser ? 'user' : 'assistant', text });
}

function showTypingIndicator() {
    const chatContainer = document.getElementById('chatContainer');
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message assistant';
    typingDiv.id = 'typingIndicator';
    
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = '✨';
    
    const content = document.createElement('div');
    content.className = 'message-content';
    
    const indicator = document.createElement('div');
    indicator.className = 'typing-indicator';
    indicator.innerHTML = '<div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div>';
    
    content.appendChild(indicator);
    typingDiv.appendChild(avatar);
    typingDiv.appendChild(content);
    
    chatContainer.appendChild(typingDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

function removeTypingIndicator() {
    const typingIndicator = document.getElementById('typingIndicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

function speak(text) {
    if (synthesis.speaking) {
        synthesis.cancel();
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;
    
    utterance.onstart = () => {
        updateStatus('Speaking...', 'processing');
    };
    
    utterance.onend = () => {
        updateStatus('Ready', 'ready');
    };

    synthesis.speak(utterance);
}

async function sendMessage() {
    const input = document.getElementById('messageInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    input.value = '';
    addMessage(message, true);
    showTypingIndicator();
    updateStatus('Processing...', 'processing');
    
    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify({ message })
        });
        
        const data = await response.json();
        
        removeTypingIndicator();
        
        if (data.error) {
            addMessage('Error: ' + data.error, false);
            updateStatus('Error', 'error');
        } else {
            addMessage(data.response, false);
            speak(data.response);
            updateStatus('Ready', 'ready');
            
            if (data.intent === 'task') {
                loadTasks();
            }
        }
    } catch (error) {
        removeTypingIndicator();
        addMessage('Sorry, I encountered an error: ' + error.message, false);
        updateStatus('Error', 'error');
    }
}

function handleKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

async function loadTasks() {
    try {
        const response = await fetch('/api/tasks', {
            credentials: 'include'
        });
        const tasks = await response.json();
        
        const taskList = document.getElementById('taskList');
        taskList.innerHTML = '';
        
        if (tasks.length === 0) {
            taskList.innerHTML = '<div style="text-align: center; color: var(--text-secondary); padding: 2rem;">No tasks yet</div>';
            return;
        }
        
        tasks.forEach(task => {
            const taskItem = document.createElement('div');
            taskItem.className = `task-item ${task.completed ? 'completed' : ''}`;
            
            const checkbox = document.createElement('div');
            checkbox.className = `task-checkbox ${task.completed ? 'checked' : ''}`;
            checkbox.onclick = () => toggleTask(task.id, !task.completed);
            
            const text = document.createElement('div');
            text.className = 'task-text';
            text.textContent = task.text;
            
            taskItem.appendChild(checkbox);
            taskItem.appendChild(text);
            taskList.appendChild(taskItem);
        });
    } catch (error) {
        console.error('Error loading tasks:', error);
    }
}

async function toggleTask(taskId, completed) {
    try {
        await fetch('/api/tasks', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify({ id: taskId, completed })
        });
        loadTasks();
    } catch (error) {
        console.error('Error updating task:', error);
    }
}

async function clearTasks() {
    if (!confirm('Are you sure you want to clear all tasks?')) {
        return;
    }
    
    try {
        const response = await fetch('/api/tasks', {
            credentials: 'include'
        });
        const tasks = await response.json();
        
        for (const task of tasks) {
            await fetch(`/api/tasks?id=${task.id}`, {
                method: 'DELETE',
                credentials: 'include'
            });
        }
        
        loadTasks();
    } catch (error) {
        console.error('Error clearing tasks:', error);
    }
}

function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('visible');
}

async function checkStatus() {
    try {
        const response = await fetch('/api/status', {
            credentials: 'include'
        });
        const status = await response.json();
        
        if (!status.gemini_configured) {
            updateStatus('Gemini API not configured', 'error');
        }
    } catch (error) {
        console.error('Error checking status:', error);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    loadTasks();
    checkStatus();
    
    const messageInput = document.getElementById('messageInput');
    messageInput.focus();
});
